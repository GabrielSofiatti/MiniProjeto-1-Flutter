import 'package:coach_motivacional/views/home.dart';
import 'package:flutter/material.dart';

void main(){

  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    title: "Coach Motivacional",
    home: Home(),
  ));

}