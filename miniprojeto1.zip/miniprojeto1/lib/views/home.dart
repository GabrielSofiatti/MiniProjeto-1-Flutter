import 'dart:math';

import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  const Home({ Key? key }) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {

  final List<String> _frases = [
    "Nunca desista dos seus sonhos!!!",
    "SIM algum dia uma e-girl vai aparecer : D",
    "Não desista o PLATINA é real!!!!!!!!!",
    "Para animar o seu dia a dia amasse um deck de exodia ^°^",
    "Não pick shaco só psicopata anticristo faz essas coisas :'(",
    "Assista Bunny Girl >.<",
    "Trabalhe enquanto eles dormem!!!",
    "Durma enquanto eles trabalham...",
  ];

  String _fraseGerada = "Clique abaixo para gerar uma frase!";

  void gerarFrase(){
    int numeroSorteado = Random().nextInt(_frases.length);
    setState(() {
      _fraseGerada = _frases[numeroSorteado];
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:const Text("Coach Motivacional"),
        backgroundColor: Colors.blue.shade900,
        
      ),
      body: Container(
        width: double.infinity,
        color: Colors.white,
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset('images/coach.png'),
            Text(_fraseGerada,style: const TextStyle(
              fontSize: 17,
              fontStyle: FontStyle.italic,
              color: Colors.black87,
            ),
            textAlign: TextAlign.justify,
            ),
            ElevatedButton(
              onPressed: gerarFrase,
              child: const Text("Nova Frase"),
              style: ElevatedButton.styleFrom(
                primary: Colors.blue.shade900,
                textStyle: const TextStyle(
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              )
          ],
        ),
      ),
    );
  }
}